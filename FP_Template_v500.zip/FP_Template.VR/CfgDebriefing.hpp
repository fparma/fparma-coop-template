// https://community.bistudio.com/wiki/Debriefing

class End1 {
  title = "Mission Success";
  description = "You have completed the mission."; 
  subtitle = "";
  picture = "b_inf"; // can be markers, paa files
  // pictureBackground = "";
  // pictureColor[] = {};
};

class Loser {
  title = "Mission Failure";
  description = "You have failed the mission, better luck next time";
  subtitle = "";
  picture = "\a3\Ui_f\data\GUI\Cfg\Debriefing\endDefault_ca.paa";
  // pictureBackground = "";
  // pictureColor[] = {};
};
